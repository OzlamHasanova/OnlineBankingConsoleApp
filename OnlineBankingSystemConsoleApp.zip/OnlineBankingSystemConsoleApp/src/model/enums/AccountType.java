package model.enums;

public enum AccountType {
    ADMIN,
    CUSTOMER
}
